# metodos-equipo2
Team repository for numerical methods class
